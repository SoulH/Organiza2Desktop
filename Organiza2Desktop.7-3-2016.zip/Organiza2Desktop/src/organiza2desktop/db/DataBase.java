/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package organiza2desktop.db;

import com.sybase.jdbc3.jdbc.SybDriver;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author soul
 */
public class DataBase {
    //Atributos
    public Connection conn;
    private static SybDriver sydriver;
    private final String driver = "com.sybase.jdbc3.jdbc.SybDriver";
    private final String PUERTO = "";
    private final String SERVIDOR = "";
    private final String BD = "";
    private final String url= "jdbc:sybase:Tds:"+SERVIDOR+":"+PUERTO+"/"+BD;//"jdbc:sybase:Tds:nombre_del_servidor:puerto"//"jdbc:postgresql://localhost:5432/NSys";
    //Metodos
    public DataBase(){
        conn = null;
    }
    
    public boolean connection(String user, String pass){
        if (conn != null) {
            JOptionPane.showMessageDialog(null, "Ya se encuenta conectado.\nRealice antes la desconexión.");
            return false;
        }
        try {
            Class.forName(driver);
            conn = DriverManager.getConnection(url, user, pass);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
            return false;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex.getMessage());
            return false;
        }
        return true;
    }
    
    public boolean desconnection(){
        if (conn != null) {
            try {
                conn.close();
            }
            catch(SQLException e){
                JOptionPane.showMessageDialog(null, e.getMessage());
                return false;
            }
            return true;
        }
        return false;
    }
}
