/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package organiza2desktop.app;

import organiza2desktop.db.DataBase;
import organiza2desktop.vista.Login;
import organiza2desktop.vista.MainWindow;

/**
 *
 * @author soul
 */
public class Organiza2Desktop {
    public DataBase db;
    public Login login;
    public MainWindow app;

    public Organiza2Desktop() {
        db = new DataBase();
        app = null;
        login = new Login(this);
        login.setVisible(true);
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Organiza2Desktop app = new Organiza2Desktop();
        /*
        lo de abajo solo es para mostrar la otra ventana ya que
        desde la aplicacion solo se veria si nos logramos conectar 
        a la base de datos, y de momento no es posible
        */
        new MainWindow().setVisible(true);
        /*
        en MainWindow hay un panel llamado content, pretendo que sea 
        para instarciar paneles preparados y dependiendo de la opcion 
        que se seleccione de los botones de arriba, por ejemplo al
        pulsar nuevo horario se instancia un panel preparado previamente 
        que contenga todo lo necesario para crear horarios, de modo que 
        todo se haga en una misma ventana
        */
    }
    
}
